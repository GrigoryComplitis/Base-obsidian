#!/bin/bash
#Запуск сервера в docker контейнере:
if docker ps | grep rtsp-simple-server | grep -v grep > /dev/null; then #проверка запущен ли контейнер
  echo "контейнер rtsp-simple-server уже запущен"
else
  docker run --rm --name rtsp-simple-server -d --network=host aler9/rtsp-simple-server
fi

#Запуск трансляций:
let "counter=1"
mystream=camera #название потока
list=list.txt  #список для трансляции
ip_addr=`ip a | grep "global" | grep -m1 "wlo1" | awk '{print $2}' | awk -F "/" '{print $1}'` #ip адрес сервера
for FILE in $(cat list.txt) #чтение списка аргументов


do
  if ps -aux | grep rtsp://localhost:8554/${mystream}${counter} | grep -v grep > /dev/null; then #проверка запущен ли поток
  echo "${mystream}${counter} уже запущен"
else
  ffmpeg -re -stream_loop -1 -i $FILE -c copy -f rtsp -rtsp_transport tcp rtsp://localhost:8554/${mystream}${counter} &>/dev/null &
  echo "запуск трансляции: $FILE in ${mystream}${counter}"
fi
let "counter+=1"
done
  sleep 1

for ((N=1; N < $counter; N++)) #вывод информации о запущенных трансляциях
do

if ps -aux | grep ${mystream}$N | grep -v grep > /dev/null; then
  echo -e "\033[32mrtsp://:@${ip_addr}:8554/${mystream}$N запущен\033[0m"
else
  echo -e "\033[31mrtsp://:@${ip_addr}:8554/${mystream}$N ошибка запуска\033[0m"
fi
done



#if ps -aux | grep vlc | grep -v grep > /dev/null; then #вывод информации о запуске ffmpeg
#  echo -e "\033[32mVLC запущен\033[0m"
#else
#  echo -e "\033[31mошибка запуска VLC\033[0m"
#fi
