#!/bin/bash
docker stop rtsp-simple-server
